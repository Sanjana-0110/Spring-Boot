package com.spring.sprint_boot_mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SprintBootMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
