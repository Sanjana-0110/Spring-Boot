package com.spring.sprint_boot_mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SprintBootMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(SprintBootMvcApplication.class, args);
	}

}
